export const STARWARS  = `starwars`;
export const PEANUTS  = `peanuts`;